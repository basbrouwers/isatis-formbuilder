<?php
/**
 * Created by PhpStorm.
 * User: basb
 * Date: 2/10/2015
 * Time: 11:28 AM
 */

class Isatis_Formbuilder_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup
{
}