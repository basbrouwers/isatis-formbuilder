<?php

class Isatis_Formbuilder_Helper_Filewriter_Data extends Mage_Core_Helper_Abstract
{

}
