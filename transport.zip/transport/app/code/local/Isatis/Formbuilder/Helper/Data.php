<?php
/**
 * Created by PhpStorm.
 * User: basb
 * Date: 1/22/2015
 * Time: 11:19 AM
 */ 
class Isatis_Formbuilder_Helper_Data extends Mage_Core_Helper_Abstract {

}