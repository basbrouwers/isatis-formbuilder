<?php

/**
 * Created by PhpStorm.
 * User: basb
 * Date: 3/27/2015
 * Time: 11:53 AM
 */
class Isatis_Formbuilder_Helper_Validator extends Mage_Core_Helper_Abstract
{
    var $validationRules = array('validate-no-html-tags'=>'/?!<(\/)?\w+>/',
        'validate-email'=>"/^([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-])+(\.([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-])+)*@([a-z0-9-]|)+(\.([a-z0-9-]|)+)*\.(([a-z]|){2,})$/i");


    var $postData = '';
    var $objForm = '';
    var $validationResults = array();
    var $elementKeys = array();
    var $elements = array();

    public function validateForm()
    {

        
        $this->postData = $this->_getRequest()->getPost();
        //see what elements are stored in the submitted form and get their id's
        $this->extractElementIds('',$this->postData);

        //fetch the elements from the database
        $this->elements = Mage::getModel('formbuilder/element')->getCollection()->addFieldToFilter('element_id', array('in',$this->elementKeys))->getData();


        //transpose the elements array so the element_id= key
        foreach($this->elements as $key=>$element) {
            $this->elements[$element['element_id']]  = $element;
            unset($this->elements[$key]);
        }
        foreach ($this->postData as $key=>$value) {
            $this->validateElement($key, $value);
        }

        return $this->validationResults;
    }

    /**
     * @param $key string
     * @param $data string|array
     */
    private function extractElementIds($key,$data)
    {
        if (!is_array($data)) {
            $elementID = array_pop(explode('-', $key));
            if(is_numeric($elementID)) {
                $this->elementKeys[]=$elementID;
            }
        } else {
            foreach ($data as $elementKey => $elementData) {
                $this->extractElementIds($elementKey,$elementData);
            }
        }
    }

    /**
     * @param $key string
     * @param $data string|array
     */
    private function validateElement($key, $data)
    {
        if (!is_array($data)) {
            $element_id = array_pop(explode('-', $key));
            $validationRule = $this->validationRules[$this->elements[$element_id]['validationrule']];
            $result = preg_match($validationRule,$data);

            if($result===0) {
                $this->validationResults[$element_id][$validationRule][$data] = $result;
            }
        } else {
            foreach ($data as $elementKey => $elementData) {
                $this->validateElement($elementKey, $elementData);
            }
        }

    }

}

